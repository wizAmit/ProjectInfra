-- phpMyAdmin SQL Dump
-- http://www.phpmyadmin.net

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- --------------------------------------------------------

--
-- Table structure for table `users3`
--

CREATE TABLE `users3` (
  `user` varchar(8) NOT NULL,
  `pass` varbinary(255) NOT NULL,
  PRIMARY KEY  (`user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users3`
--

INSERT INTO `users3` VALUES('jharvard', 'ãçgŽ¡Ë«-\ZdÏûÖ4i');
