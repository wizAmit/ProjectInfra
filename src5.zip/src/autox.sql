-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 08, 2009 at 09:37 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `autox`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` mediumint(9) unsigned NOT NULL auto_increment,
  `make` varchar(20) NOT NULL,
  `model` varchar(20) NOT NULL,
  `year` year(4) NOT NULL,
  `class` tinyint(4) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` VALUES(1, 'Ford', 'Pinto', 1975, 5);
INSERT INTO `cars` VALUES(2, 'Volkswagen', 'Beetle', 1971, 4);
INSERT INTO `cars` VALUES(4, 'Porsche', '911 GT3 RS', 2008, 1);

-- --------------------------------------------------------

--
-- Table structure for table `drivers`
--

CREATE TABLE `drivers` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL,
  `age` smallint(6) NOT NULL,
  `year_started` year(4) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `drivers`
--

INSERT INTO `drivers` VALUES(1, 'John Harvard', 27, 2006);
INSERT INTO `drivers` VALUES(2, 'Jane Harvard', 30, 2004);
INSERT INTO `drivers` VALUES(3, 'John Smith', 18, 2008);
INSERT INTO `drivers` VALUES(4, 'Jane Doe', 32, 2000);

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `date` datetime NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `events`
--

INSERT INTO `events` VALUES(1, '2009-06-27 14:30:36', 'Held at Devens Airport in Ayer, MA. Dry conditions in the morning but pouring rain in the afternoon.');
INSERT INTO `events` VALUES(2, '2009-07-04 14:32:13', 'A sunny and warm 4th of July autocross.');

-- --------------------------------------------------------

--
-- Table structure for table `times`
--

CREATE TABLE `times` (
  `driver_id` int(11) unsigned NOT NULL,
  `event_id` int(11) unsigned NOT NULL,
  `car_id` mediumint(8) unsigned NOT NULL,
  `am_run1` decimal(6,3) NOT NULL,
  `am_run2` decimal(6,3) NOT NULL,
  `pm_run1` decimal(6,3) NOT NULL,
  `pm_run2` decimal(6,3) NOT NULL,
  PRIMARY KEY  (`driver_id`,`event_id`,`car_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `times`
--

INSERT INTO `times` VALUES(4, 1, 3, 68.043, 64.001, 72.023, 71.120);
INSERT INTO `times` VALUES(1, 1, 1, 72.560, 70.230, 76.540, 75.890);
INSERT INTO `times` VALUES(4, 2, 4, 50.060, 45.780, 45.455, 43.223);
