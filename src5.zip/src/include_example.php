<?php

    // Here are some MySQL login credentials
    define("HOST", "localhost");
    define("USER", "danallan_lecture");
    define("PASS", "12345");

	// define the database name
	define("DB", "danallan_lecture");