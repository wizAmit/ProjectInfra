<?php
	$name = $_POST['action'];
	$query = "select name, 'univ roll no' from details_stu where name like " . $name . "%;";
	function getDetails($conn){
		foreach($conn->query($query) as $row){
			print $row['Univ Roll No'] . "\t";
			print $row['Full Name'] . "\n";
		}
	}
?>
