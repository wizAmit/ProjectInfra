<?php

	//Here goes the MySQL login creds
	define("HOST","db4free.net:3306");
	define("USER","wizamit");
	define("PASS","wizard10789");

	//Now defined is db name
	define("DB","cse10214");
