<?php
	//get MySQL login and db creds
	require "include.php";
	
	//enable sessions
	session_start();
?>

<!DOCTYPE html>
<html>
	<head>
		<title>Details Form</title>
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	</head>
	<body>
		<form>
			<input type="text" id="name"></input>
			<div id="result"></div>
		</form>	
	</body>
	<script>
	("#name").keypress(function(){
		$.ajax({ url: './execQuery.php',
			data: {action: $("#name").text},
			type: 'post',
			success: alert("Hurray!");
		});
	</script>
</html>
